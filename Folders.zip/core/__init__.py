# Core module for crypto trading bot
