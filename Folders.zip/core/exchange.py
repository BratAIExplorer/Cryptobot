import ccxt
import pandas as pd
import time
import os

class ExchangeInterface:
    def __init__(self, mode='paper'):
        self.mode = mode
        self.exchange_id = 'binance'
        
        # Load API keys from environment (supporting multiple naming conventions)
        api_key = os.environ.get('BINANCE_API_KEY') or os.environ.get('BINANCE_API_KEY_ID')
        secret = os.environ.get('BINANCE_SECRET_KEY') or os.environ.get('BINANCE_API_KEY_SECRET')
        
        config = {
            'enableRateLimit': True,
            'options': {
                'defaultType': 'spot',  # spot trading
            }
        }
        
        if api_key and secret:
            config['apiKey'] = api_key
            config['secret'] = secret
            print(f"✅ Authenticated with Binance API")
        else:
            print(f"⚠️  Running in Public/Read-Only Mode (No Keys Found)")

        self.exchange = ccxt.binance(config)
        
        # Load markets
        try:
            self.exchange.load_markets()
            print(f"Connected to {self.exchange_id}")
        except Exception as e:
            print(f"Error connecting to exchange: {e}")

    def fetch_ticker(self, symbol):
        """Fetch current price for a symbol"""
        try:
            ticker = self.exchange.fetch_ticker(symbol)
            return ticker
        except Exception as e:
            print(f"Error fetching ticker for {symbol}: {e}")
            return None

    def fetch_ohlcv(self, symbol, timeframe='1h', limit=100):
        """Fetch historical data"""
        try:
            ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            return df
        except Exception as e:
            print(f"Error fetching OHLCV for {symbol}: {e}")
            return pd.DataFrame()

    def get_fee_rate(self, symbol):
        """Get trading fee rate"""
        # Default to 0.1% if not found
        return 0.001 

    def create_order(self, symbol, side, amount, price=None):
        """Execute a live order on Binance"""
        try:
            if price:
                # Limit Order
                order = self.exchange.create_order(symbol, 'limit', side, amount, price)
            else:
                # Market Order
                order = self.exchange.create_order(symbol, 'market', side, amount)
            return order
        except Exception as e:
            print(f"❌ EXECUTION ERROR: {e}")
            return None

    def get_balance(self, currency='USDT'):
        """Get live wallet balance"""
        try:
            balance = self.exchange.fetch_balance()
            return balance['total'].get(currency, 0.0)
        except Exception as e:
            print(f"Error fetching balance: {e}")
            return 0.0

    def fetch_balance(self):
        """Fetch full balance object from exchange"""
        try:
            return self.exchange.fetch_balance()
        except Exception as e:
            print(f"Error fetching balance: {e}")
            return {'total': {}, 'free': {}}
