# Strategies module for crypto trading bot
