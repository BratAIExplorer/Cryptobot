# Utilities module for crypto trading bot
